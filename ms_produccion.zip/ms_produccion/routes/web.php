<?php

$router->group(['prefix' => 'auth'], function () use ($router) {
    $router->post('login', 'AuthController@login');
});

$router->group(['prefix' => 'api', 'middleware' => 'auth'], function () use ($router) {
    $router->get('/produccion', 'ProduccionController@index');
    $router->post('/produccion', ['middleware' => 'role:admin', 'uses' => 'ProduccionController@store']);
    $router->get('/produccion/{id}', 'ProduccionController@show');
    $router->put('/produccion/{id}', ['middleware' => 'role:admin', 'uses' => 'ProduccionController@update']);
    $router->delete('/produccion/{id}', ['middleware' => 'role:admin', 'uses' => 'ProduccionController@destroy']);
});