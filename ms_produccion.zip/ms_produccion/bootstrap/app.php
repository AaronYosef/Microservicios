<?php

require_once __DIR__.'/../vendor/autoload.php';

(new Laravel\Lumen\Bootstrap\LoadEnvironmentVariables(
    dirname(__DIR__)
))->bootstrap();

date_default_timezone_set(env('APP_TIMEZONE', 'UTC'));

// Primero crea la instancia de $app
$app = new Laravel\Lumen\Application(
    dirname(__DIR__)
);

// Configuraciones básicas
$app->withFacades();
$app->withEloquent();

$app->middleware([
    App\Http\Middleware\CorsMiddleware::class,
    App\Http\Middleware\SecurityHeadersMiddleware::class,
]);

// Registro de proveedores de servicios
$app->register(App\Providers\AuthServiceProvider::class);
$app->register(\Illuminate\Filesystem\FilesystemServiceProvider::class);
$app->register(Tymon\JWTAuth\Providers\LumenServiceProvider::class);

// Middlewares
$app->routeMiddleware([
    'auth' => App\Http\Middleware\Authenticate::class,
    'role' => App\Http\Middleware\RoleMiddleware::class,
]);

$app->register(App\Providers\AuthServiceProvider::class);
$app->register(Tymon\JWTAuth\Providers\LumenServiceProvider::class);

// Configuraciones
$app->configure('app');
$app->configure('jwt');

// Handlers de excepciones y consola
$app->singleton(
    Illuminate\Contracts\Debug\ExceptionHandler::class,
    App\Exceptions\Handler::class
);

$app->singleton(
    Illuminate\Contracts\Console\Kernel::class,
    App\Console\Kernel::class
);

// Rutas
$app->router->group([
    'namespace' => 'App\Http\Controllers',
], function ($router) {
    require __DIR__.'/../routes/web.php';
});

return $app;