<?php
return [
    'allowed_origins' => explode(',', env('CORS_ALLOWED_ORIGINS')),
    'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    'allowed_headers' => ['Content-Type', 'Authorization'],
];