<?php

namespace App\Http\Controllers;

use App\Models\Produccion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProduccionController extends Controller
{
    /**
     * Obtener todas las producciones (con filtros y paginación)
     */
    public function index(Request $request)
    {
        try {
            // Validación de parámetros
            $validator = Validator::make($request->all(), [
                'filtro_fecha' => 'sometimes|date_format:Y-m-d',
                'estado' => ['sometimes', Rule::in(['activo', 'inactivo', 'pendiente'])],
                'limit' => 'sometimes|integer|min:1|max:100'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'error' => 'Parámetros inválidos',
                    'details' => $validator->errors()
                ], 400);
            }

            // Consulta segura con Eloquent
            $query = Produccion::query();
            
            // Filtros
            if ($request->has('filtro_fecha')) {
                $query->whereDate('inicio_produccion', $request->filtro_fecha);
            }

            if ($request->has('estado')) {
                $query->where('estado', $request->estado);
            }

            // Paginación segura (máx 100 por página)
            $perPage = $request->get('limit', 10);
            $producciones = $query->paginate($perPage);

            // Log de auditoría
            Log::channel('audit')->info('Consulta de producción', [
                'user_id' => auth()->user()->id,
                'filters' => $request->all()
            ]);

            return response()->json([
                'data' => $producciones->items(),
                'meta' => [
                    'total' => $producciones->total(),
                    'current_page' => $producciones->currentPage(),
                    'per_page' => $producciones->perPage(),
                    'last_page' => $producciones->lastPage()
                ]
            ]);

        } catch (\Exception $e) {
            Log::channel('error')->error('Error en ProduccionController@index', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Error interno del servidor'], 500);
        }
    }

    /**
     * Crear una nueva producción
     */
    public function store(Request $request)
    {
        try {
            // Validación estricta
            $validatedData = $this->validate($request, [
                'cantidad_maiz' => 'required|numeric|min:0',
                'cantidad_agua' => 'required|numeric|min:0',
                'cantidad_gas' => 'required|numeric|min:0',
                'cantidad_cal' => 'required|numeric|min:0',
                'inicio_produccion' => 'required|date_format:Y-m-d H:i:s',
                'fin_produccion' => 'nullable|date_format:Y-m-d H:i:s|after:inicio_produccion',
                'estado' => ['required', Rule::in(['activo', 'inactivo', 'pendiente'])],
                'notas' => 'nullable|string|max:500'
            ]);

            // Asignar usuario autenticado
            $validatedData['user_id'] = auth()->user()->id;

            // Crear registro
            $produccion = Produccion::create($validatedData);

            // Log de creación
            Log::channel('audit')->info('Producción creada', [
                'user_id' => auth()->user()->id,
                'produccion_id' => $produccion->id_produccion
            ]);

            return response()->json($produccion, 201);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'error' => 'Validación fallida',
                'details' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::channel('error')->error('Error en ProduccionController@store', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Error al crear producción'], 500);
        }
    }

    /**
     * Mostrar una producción específica
     */
    public function show($id)
    {
        try {
            // Validar ID
            if (!is_numeric($id)) {
                return response()->json(['error' => 'ID inválido'], 400);
            }

            // Buscar con seguridad
            $produccion = Produccion::findOrFail($id);

            // Verificar propiedad (opcional)
            if (auth()->user()->role !== 'admin' && $produccion->user_id !== auth()->user()->id) {
                return response()->json(['error' => 'No autorizado'], 403);
            }

            return response()->json($produccion);

        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => 'Producción no encontrada'], 404);
        } catch (\Exception $e) {
            Log::channel('error')->error('Error en ProduccionController@show', [
                'message' => $e->getMessage(),
                'id' => $id
            ]);
            return response()->json(['error' => 'Error interno'], 500);
        }
    }

    /**
     * Actualizar una producción
     */
    public function update(Request $request, $id)
    {
        try {
            // Validar ID
            if (!is_numeric($id)) {
                return response()->json(['error' => 'ID inválido'], 400);
            }

            // Buscar registro
            $produccion = Produccion::findOrFail($id);

            // Verificar permisos
            if (auth()->user()->role !== 'admin' && $produccion->user_id !== auth()->user()->id) {
                return response()->json(['error' => 'No autorizado'], 403);
            }

            // Validación
            $validatedData = $this->validate($request, [
                'cantidad_maiz' => 'sometimes|numeric|min:0',
                'estado' => ['sometimes', Rule::in(['activo', 'inactivo', 'pendiente'])],
                'notas' => 'nullable|string|max:500'
            ]);

            // Actualizar
            $produccion->update($validatedData);

            // Log de auditoría
            Log::channel('audit')->info('Producción actualizada', [
                'user_id' => auth()->user()->id,
                'produccion_id' => $id,
                'changes' => $validatedData
            ]);

            return response()->json($produccion);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'error' => 'Validación fallida',
                'details' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::channel('error')->error('Error en ProduccionController@update', [
                'message' => $e->getMessage(),
                'id' => $id
            ]);
            return response()->json(['error' => 'Error al actualizar'], 500);
        }
    }

    /**
     * Eliminar una producción
     */
    public function destroy($id)
    {
        try {
            // Validar ID
            if (!is_numeric($id)) {
                return response()->json(['error' => 'ID inválido'], 400);
            }

            $produccion = Produccion::findOrFail($id);

            // Solo admin o creador puede eliminar
            if (auth()->user()->role !== 'admin' && $produccion->user_id !== auth()->user()->id) {
                return response()->json(['error' => 'No autorizado'], 403);
            }

            // Eliminar
            $produccion->delete();

            // Log de auditoría
            Log::channel('audit')->info('Producción eliminada', [
                'user_id' => auth()->user()->id,
                'produccion_id' => $id
            ]);

            return response()->json(['message' => 'Producción eliminada']);

        } catch (\Exception $e) {
            Log::channel('error')->error('Error en ProduccionController@destroy', [
                'message' => $e->getMessage(),
                'id' => $id
            ]);
            return response()->json(['error' => 'Error al eliminar'], 500);
        }
    }
}