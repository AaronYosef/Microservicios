<?php
namespace App\Http\Middleware;

use Closure;
use Firebase\JWT\JWT;
use Firebase\JWT\Key; // ¡Asegúrate de importar esta clase!
use Exception;

class JwtMiddleware
{
    public function handle($request, Closure $next)
    {
        try {
            $token = $request->header('Authorization') ? trim(str_replace('Bearer', '', $request->header('Authorization'))) : null;
            
            if (!$token) {
                throw new Exception('Token no proporcionado');
            }
            
            // Corrección aquí: cerrar paréntesis y usar Key correctamente
            $decoded = JWT::decode($token, new Key(env('JWT_SECRET'), 'HS256'));
            
            return $next($request);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No autorizado',
                'details' => $e->getMessage() // Opcional: para debug en desarrollo
            ], 401);
        }
    }
}