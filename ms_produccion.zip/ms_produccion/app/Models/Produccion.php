<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produccion extends Model
{
    protected $table = 'produccion';
    protected $primaryKey = 'id_produccion';
    public $timestamps = false;

    protected $fillable = [
        'cantidad_maiz', 'cantidad_agua', 
        'cantidad_gas', 'cantidad_cal', 'notas', 
        'inicio_produccion','fin_produccion', 'estado'
    ];
}
