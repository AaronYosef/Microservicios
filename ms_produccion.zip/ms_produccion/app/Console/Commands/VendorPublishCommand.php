<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class VendorPublishCommand extends Command
{
    protected $signature = 'vendor:publish';
    protected $description = 'Publish any publishable assets from vendor packages';

    public function handle()
    {
        $this->call('publish:config');
        $this->call('publish:migrations');
        $this->call('publish:views');
        $this->info('Vendor assets published successfully!');
    }
}
